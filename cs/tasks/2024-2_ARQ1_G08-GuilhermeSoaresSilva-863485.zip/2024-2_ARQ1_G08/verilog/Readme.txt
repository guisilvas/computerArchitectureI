Nome: Guilherme Soares Silva
Matricula: 863485

Observações sobre o Guia 08: Peço desculpas pelos guias incompletos enviados até aqui, não dei a devida importância às tarefas até o momento. Estou refanzendo-as como preparação para a prova. Realizei as atividades de hoje em Verilog, algumas não consegui terminar no Logisim, só agora que estou utilizando esta ferramenta para realizar os testes que não havia feito anteriormente mas acredito que estou obtendo progresso.
Mais umas vez peço desculpas e agradeço pelo ensino de excelência.
