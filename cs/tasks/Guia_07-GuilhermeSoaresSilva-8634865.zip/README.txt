Observação: Não realizei a atividade do Guia 6 nem as questões em Logisim por conta das provas de AEDSII, caso seja permitido em breve reenviarei. Peço desculpas.
Guilherme Soares Silva
